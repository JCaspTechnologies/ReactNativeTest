export const ACTION_TYPE_SECRVICE_CALL = {
    SUCCESS : 'success',
    ERROR : 'error',
    LOADING : 'loading',
}
