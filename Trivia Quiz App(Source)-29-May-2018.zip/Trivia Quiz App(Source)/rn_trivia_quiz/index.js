import { AppRegistry } from 'react-native';
import App from './App';
import HomeScreen from './src/containers/HomeScreen.js';

AppRegistry.registerComponent('rn_trivia_quiz', () => App);
