import React, {Component} from 'react';
import DOMParser from 'react-native-html-parser';
import {
  View,
  Text,
  Alert,
  Button,
  StyleSheet,
} from 'react-native';

var data = null;
var correctQuestion = [];
var wrongQuestion = [];
var allQuestion = [];
var queAnsArr = [];
var totalQuestion = 0;
var currentQuestion=0;
var cnt;

const Entities = require('html-entities').AllHtmlEntities;
const entities = new Entities();

export default class QuizScreen extends Component{

  constructor(props){
    super(props)
    this.state ={
      responseState:null,
      question:'',
      category:'',
      ansTrue:'',
      ansFalse:'',
    }
  }

  static navigationOptions = {
          header: null,
      };

  componentDidMount(){
    data = this.props.navigation.state.params.response;
    this.setState({responseState:data});
    totalQuestion = data.results.length;
    cnt = 0;
    this.setState({question:entities.decode(data.results[cnt].question)})
    this.setState({category:data.results[cnt].category})
  }

  render(){
    const { navigate } = this.props.navigation;
    return(
      <View style={styles.container}>
          <Text style={styles.titleText}>{this.state.category}</Text>
          <View style={{justifyContent:'center',alignItems:'center'}}>
            <View style={styles.questionBox}>
              <View style={{height:'70%'}}>
              <Text style={styles.question}>{this.state.question}</Text>
              </View>

              <View style={styles.answerContainer}>
              <Text style={styles.answerTrue} onPress={()=>this.changeQuestion('True')}>True</Text>
              <Text style={styles.answerFalse} onPress={()=>this.changeQuestion('False')}>False</Text>
              </View>
            </View>
            <Text style={styles.counter}>{cnt+1} / {totalQuestion}</Text>
          </View>
      </View>
    );
  }

  changeQuestion(answer){
    if(cnt <= (totalQuestion-1))
    {
      if(answer == data.results[cnt].correct_answer)
      {
        correctQuestion.push(data.results[cnt]);
      }else {
          wrongQuestion.push(data.results[cnt]);
      }

      queAnsArr.push({
        "question":data.results[cnt].question,
        "userAns" : answer,
        "correctAns" : data.results[cnt].correct_answer});

        allQuestion.push(data.results[cnt]);
        cnt = cnt+1;
        if(cnt <= (totalQuestion-1)){

        this.setState({question:entities.decode(data.results[cnt].question)});
        this.setState({category:data.results[cnt].category});
      }
    }else{
      // Redirect on result screen
      this.props.navigation.navigate('ResultScreen',
      {correctQuestion:JSON.stringify(correctQuestion),
        wrongQuestion:JSON.stringify(wrongQuestion),
        allQuestion:JSON.stringify(allQuestion),
        queAnsArr:JSON.stringify(queAnsArr)})
      }
    }
  }


const styles = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor:'white',
  },
  titleText:{
    fontSize:20,
    height:'10%',
    fontWeight:'bold',
    color:'black',
    textAlign:'left',
    margin:'5%',
  },
  questionBox:{
    borderWidth:1,
    borderColor:'black',
    width:'85%',
    aspectRatio:1,
    marginTop:'10%',
  },
  counter:{
    color:'black',
    marginTop:'5%',
  },
  question:{
    fontSize:18,
    color:'black',
    textAlign:'left',
    margin:'3%',
  },
  answerTrue:{
    fontSize:20,
    color:'green',
    textAlign:'left',
    padding:'5%',
    fontWeight:'bold',
  },
  answerFalse:{
    fontSize:20,
    color:'red',
    textAlign:'left',
    padding:'5%',
    fontWeight:'bold',
  },
  answerContainer:{
    height:'30%',
    alignItems:'center',
    justifyContent:'center',
    flexDirection:'row'
  }
});
