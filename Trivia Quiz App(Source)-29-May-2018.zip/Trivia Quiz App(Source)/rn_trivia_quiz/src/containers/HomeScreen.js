import React, {Component} from 'react';
import { connect } from 'react-redux';
import {bindActionCreators} from 'redux';
import * as ServiceCallAction from '../actions/ServiceCallAction'
import {
  View,
  Text,
  Alert,
  Button,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';

class HomeScreen extends Component{

  static navigationOptions = {
          header: null,
      };

  constructor(props){
    super(props)
  }

  componentDidMount(){
    this.props.getQuestion();
  }

  render(){

    const {isLoading,error,response} = this.props;
    const navigate = this.props.navigation;
    return(
      <View style={styles.containers}>

        <View style={styles.partitionArea}>
          <Text style = {styles.boldText}>Welcome to the{'\n'}Trivia Challange!</Text>
        </View>

        <View style={styles.partitionArea}>
          <Text style = {styles.titleText}>You will be present with 10 True or False questions.</Text>
        </View>

        <View style={styles.partitionArea}>
          <Text style = {styles.titleText}>Can you score 100% ?</Text>
        </View>

        <View style={styles.partitionArea}>
        {this.displayStatus()}
        </View>
      </View>
    )
  }

  displayStatus(){
    if(this.props.isLoading){
      return(
        <Text style = {styles.titleText}>Please Wait...</Text>
      )
    }

    if(this.props.error != null){
      return(
        <Text style = {styles.titleText}>Something is wrong, please try again</Text>
      )
    }

    if(this.props.response != null) {
      return (
        <Text style = {styles.titleText} onPress={()=> this.redirectToQuizScreen()}>BIGIN</Text>
      )
    }
  }

  redirectToQuizScreen(){
    this.props.navigation.navigate('QuizScreen',{response:this.props.response});
  }
}

const mapStateToProps = (state) => ({
    isLoading: state.serviceCallReducers.isLoading,
    error: state.serviceCallReducers.error,
    response: state.serviceCallReducers.response,
});

function mapDispatchToProps(dispatch) {
  return bindActionCreators(ServiceCallAction, dispatch);
  }

export default connect(mapStateToProps,mapDispatchToProps)(HomeScreen);

const styles = StyleSheet.create({
  containers:{
    flex:1,
    backgroundColor:'white',
  },
  partitionArea:{
    height:'25%',
    alignItems:'center',
    justifyContent:'center',
    padding:'15%',
  },
  boldText:{
    fontSize:22,
    fontWeight:'bold',
    color:'black',
    textAlign:'center',
  },
  titleText:{
    fontSize:20,
    fontWeight:'normal',
    color:'black',
    textAlign:'center',
  }
});
