import { ACTION_TYPE_SECRVICE_CALL } from './ActionType.js';
import { connect } from 'react-redux';
import DOMParser from 'react-native-html-parser';
import {API} from '../helper/Constant.js';
import {Alert} from 'react-native';
import HomeScreen from '../containers/HomeScreen.js'

export function getQuestion(){
    return(dispatch,state) =>{
      dispatch({type:ACTION_TYPE_SECRVICE_CALL.LOADING});
      console.log("API.GET_QUESTION >>> "+API.GET_QUESTION);
      return fetch(API.GET_QUESTION).then(handleError).then( response => response.json()).then((response) =>{
        dispatch(serviceActionSuccess(response))
      }).catch(error =>{
        dispatch(serviceActionError(error))
        console.log("Error >> "+error);
      });
    }
}

function handleError(response){
  if(!response.ok){
    throw Error(response.statusText);
  }
  return response;
}

export const serviceActionSuccess = (response) =>({
  type:ACTION_TYPE_SECRVICE_CALL.SUCCESS,
  response:response
})

export const serviceActionError = (error) =>({
  type: ACTION_TYPE_SECRVICE_CALL.ERROR,
  error: error
})
