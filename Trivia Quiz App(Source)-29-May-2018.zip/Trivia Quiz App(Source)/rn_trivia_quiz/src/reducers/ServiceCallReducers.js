import {ACTION_TYPE_SECRVICE_CALL} from '../actions/ActionType.js';
import { Alert } from 'react-native';

const initialState={
  isLoading:true,
  response:{},
  error:null,
}

 const serviceCallReducers = (state = initialState, action) =>{
  switch (action.type) {
    case ACTION_TYPE_SECRVICE_CALL.LOADING:
      return {...state,isLoading:true,error:null};
    case ACTION_TYPE_SECRVICE_CALL.SUCCESS:
        return {...state,isLoading:false,response:action.response,error:null};
    case ACTION_TYPE_SECRVICE_CALL.ERROR:
        return {...state, isLoading:false,response: null,error:action.console.error};
    default:
      return state;
  }
}

export default serviceCallReducers;
