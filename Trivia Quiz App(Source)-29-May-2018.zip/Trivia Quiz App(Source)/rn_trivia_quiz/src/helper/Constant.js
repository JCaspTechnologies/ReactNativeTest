export const API = {
    GET_QUESTION : 'https://opentdb.com/api.php?amount=10&difficulty=hard&type=boolean',
}
