import React, {Component} from 'react';
import { connect } from 'react-redux';
import {bindActionCreators} from 'redux';
import { NativeModules } from 'react-native';
import RNRestart from 'react-native-restart';
import * as ServiceCallAction from '../actions/ServiceCallAction'

import {
  View,
  Text,
  Alert,
  Button,
  StyleSheet,
  FlatList,
} from 'react-native';

const Entities = require('html-entities').AllHtmlEntities;
const entities = new Entities();

var data = null;
var correctQuestion = 0;

class ResultScreen extends Component{

  constructor(props){
    super(props)
    this.state ={
      responseState:null,
    }
  }

  static navigationOptions = {
          header: null,
      };

  render(){

    const { navigation} = this.props;

    var allQuestion = JSON.parse(navigation.getParam('allQuestion').toString());
    correctQuestion = JSON.parse(navigation.getParam('correctQuestion').toString());
    var wrongQuestion = JSON.parse(navigation.getParam('wrongQuestion').toString());
    var queAnsArr = JSON.parse(navigation.getParam('queAnsArr').toString());
    var keys = Object.keys(queAnsArr);
    console.log("queAnsArr[keys[0] >> "+queAnsArr[keys[0]]);

    return(
      <View style={styles.container}>
        <Text style={styles.titleText}>Your scored{'\n'}{correctQuestion.length} / {allQuestion.length}</Text>
        <View style={styles.list}>
          <FlatList
              data = {queAnsArr}
              ItemSeparatorComponent={ () =>this.divider() }
              renderItem={this.renderItem}
              keyExtractor={item => item.question}/>
        </View>
        <View style={styles.playAgin}>
        <Text style={styles.playAgainText} onPress={() => this.redirectToHomeScreen('true')}>PALY AGAIN ?</Text>
      </View>
    </View>
  );
}

  renderItem({item}){
    var keys = Object.keys(item);
    var ans = item['correctAns'];
    var uans = item['userAns'];
    if(ans == uans){
      return(
        <View style={styles.questionView}>
        <Text style={styles.pmText}>+</Text>
        <Text style={{fontSize:16,}}>{entities.decode(item['question'])}</Text>
        </View>
      )
    }else {
      return(
        <View style={{flex:1,flexDirection:'row',alignItems:'center'}}>
        <Text style={styles.pmText}>-</Text>
        <Text style={{fontSize:16,}}>{entities.decode(item['question'])}</Text>
        </View>
      )
    }
  }

  divider(){
    return(
       <View style={ { width: '100%', height: 10, backgroundColor: '#00000000' } } />
    )
  }

  redirectToHomeScreen(type){
      RNRestart.Restart();
    }
}

const mapStateToProps = (state) => ({
    isLoading: state.serviceCallReducers.isLoading,
    error: state.serviceCallReducers.error,
    response: state.serviceCallReducers.response,
});


function mapDispatchToProps(dispatch) {
  return bindActionCreators(ServiceCallAction, dispatch);
  }

export default connect(mapStateToProps,mapDispatchToProps)(ResultScreen);

const styles = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor:'white',
  },
  titleText:{
    fontSize:22,
    fontWeight:'bold',
    color:'black',
    textAlign:'center',
    margin:'5%',
  },
  list:{
    marginLeft:'5%',
    marginRight:'5%',
    height:'75%',
  },
  playAgin:{
    justifyContent:'center',
    alignItems:'center',
    margin:'5%',
  },
  playAgainText:{
    fontSize:22,
    fontWeight:'bold',
    color:'black',
    textAlign:'center',
    padding:'1%',
  },
  pmText:{
    fontSize:22,
    fontWeight:'bold',
    marginRight:'4%'
  },
  questionView:{
    flex:1,
    flexDirection:'row',
    alignItems:'center'
  },
});
