import React, { Component } from 'react'
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { StackNavigator } from 'react-navigation';
import { initializeListeners, createReduxBoundAddListener } from 'react-navigation-redux-helpers';
import { navigationPropConstructor } from '../helper/redux';
import HomeScreen from '../containers/HomeScreen.js'
import QuizScreen from '../containers/QuizScreen.js'
import ResultScreen from '../containers/ResultScreen.js'

export const AppNavigator = new StackNavigator({
  HomeScreen: { screen: HomeScreen },
  QuizScreen: { screen: QuizScreen },
  ResultScreen: { screen: ResultScreen },
}, {
    initialRouteName: 'HomeScreen'
});

const addListener = createReduxBoundAddListener("root");

class AppWithNavigationState extends Component{

  static propTypes = {
   dispatch: PropTypes.func.isRequired,
   nav: PropTypes.object.isRequired,
 };

 componentDidMount() {
    initializeListeners('root', this.props.nav);
  }

  render() {
    return(
    <AppNavigator navigation={{
        dispatch: this.props.dispatch,
        state: this.props.nav,
        addListener,
      }} />
    )
  }

}

const mapStateToProps = state => ({
  nav: state.nav,
});

export default connect(mapStateToProps)(AppWithNavigationState);
