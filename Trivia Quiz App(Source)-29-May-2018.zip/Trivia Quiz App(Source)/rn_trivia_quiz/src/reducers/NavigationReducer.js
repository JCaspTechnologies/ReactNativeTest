import { NavigationActions } from 'react-navigation';

import { AppNavigator } from '../navigators/Navigator';

// Start with two routes: The Main screen, with the Login screen on top.
const firstAction = AppNavigator.router.getActionForPathAndParams('HomeScreen');
const tempNavState = AppNavigator.router.getStateForAction(firstAction);
const secondAction = AppNavigator.router.getActionForPathAndParams('QuizScreen');

const initialNavState = AppNavigator.router.getStateForAction(
  tempNavState,
);

function nav(state = initialNavState, action) {
  let nextState;
  switch (action.type) {
    case 'HomeScreen':
      nextState = AppNavigator.router.getStateForAction(
        NavigationActions.navigate({ routeName: 'HomeScreen',params: action.params}),
        state
      );
      break;
    case 'QuizScreen':
      nextState = AppNavigator.router.getStateForAction(
        NavigationActions.navigate({ routeName: 'QuizScreen' }),
        state
      );
      break;
    default:
      nextState = AppNavigator.router.getStateForAction(action, state);
      break;
  }

  // Simply return the original `state` if `nextState` is null or undefined.
  return nextState || state;
}

export default nav;
