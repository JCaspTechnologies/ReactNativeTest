import { AppRegistry } from 'react-native';
import React, { Component } from 'react';
import { Provider } from 'react-redux';
import store from './src/reducers/index.js';
import { combineReducers, applyMiddleware, createStore, compose } from 'redux';
import thunk from 'redux-thunk';
import ServiceCallAction from './src/actions/ServiceCallAction.js';
import AppWithNavigationState from './src/navigators/Navigator.js';
import rootReducer from './src/reducers/index.js';
import { middleware } from './src/helper/redux';

class TriviaQuiz extends Component {
    render() {
        return (
            <Provider store={store}>
                <AppWithNavigationState />
            </Provider>
        );
    }
}

AppRegistry.registerComponent('TriviaQuiz', () => TriviaQuiz);

export default TriviaQuiz;
